class APIRequestError(Exception):
    """Raised when an API request fails."""
    pass
